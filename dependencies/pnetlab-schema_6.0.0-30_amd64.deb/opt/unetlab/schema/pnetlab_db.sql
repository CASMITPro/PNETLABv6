-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 26, 2020 at 01:26 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.2.27-6+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eve_ng_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `control`
--

CREATE TABLE `control` (
  `control_name` varchar(150) NOT NULL,
  `control_value` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `html5`
--

CREATE TABLE `html5` (
  `username` text,
  `pod` int(11) DEFAULT NULL,
  `token` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lab_sessions`
--

CREATE TABLE `lab_sessions` (
  `lab_session_id` int(11) NOT NULL,
  `lab_session_lid` varchar(150) DEFAULT NULL,
  `lab_session_pod` int(11) DEFAULT NULL,
  `lab_session_joined` text,
  `lab_session_path` text,
  `lab_session_running` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `node_sessions`
--

CREATE TABLE `node_sessions` (
  `node_session_id` int(11) NOT NULL,
  `node_session_nid` int(11) DEFAULT NULL,
  `node_session_lab` int(11) DEFAULT NULL,
  `node_session_port` int(11) DEFAULT NULL,
  `node_session_type` varchar(150) DEFAULT NULL,
  `node_session_workspace` text,
  `node_session_ram` float DEFAULT NULL,
  `node_session_cpu` float DEFAULT NULL,
  `node_session_hdd` float DEFAULT NULL,
  `node_session_running` int(1) DEFAULT NULL,
  `node_session_pod` int(11) DEFAULT NULL,
  `node_session_iol` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `process`
--

CREATE TABLE `process` (
  `process_id` varchar(200) NOT NULL,
  `process_dtotal` int(11) DEFAULT NULL,
  `process_dnow` int(11) DEFAULT NULL,
  `process_utotal` int(11) DEFAULT NULL,
  `process_unow` int(11) DEFAULT NULL,
  `process_finish` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `process_device`
--

CREATE TABLE `process_device` (
  `process_device_id` varchar(150) NOT NULL,
  `process_device_dtotal` int(11) DEFAULT NULL,
  `process_device_dnow` int(11) DEFAULT NULL,
  `process_device_utotal` int(11) DEFAULT NULL,
  `process_device_unow` int(11) DEFAULT NULL,
  `process_device_log` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `pod` int(11) NOT NULL,
  `username` text CHARACTER SET utf8,
  `cookie` text CHARACTER SET utf8,
  `email` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `expiration` int(11) DEFAULT '-1',
  `name` text CHARACTER SET utf8,
  `password` text CHARACTER SET utf8,
  `session` int(11) DEFAULT NULL,
  `ip` text CHARACTER SET utf8,
  `role` text CHARACTER SET utf8,
  `folder` text CHARACTER SET utf8,
  `lab_session` int(11) DEFAULT NULL,
  `html5` tinyint(1) DEFAULT NULL,
  `license` text CHARACTER SET utf8,
  `online_time` int(11) DEFAULT NULL,
  `note` text CHARACTER SET utf8,
  `offline` int(1) DEFAULT NULL,
  `active_time` int(11) DEFAULT NULL,
  `expired_time` int(11) DEFAULT NULL,
  `user_status` int(2) DEFAULT '1',
  `user_workspace` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_permission`
--

CREATE TABLE `user_permission` (
  `user_per_id` int(11) NOT NULL,
  `user_per_role` int(11) DEFAULT NULL,
  `user_per_name` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_role_id` int(11) NOT NULL,
  `user_role_name` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `user_role_workspace` text CHARACTER SET utf8,
  `user_role_note` text CHARACTER SET utf8,
  `user_role_ram` float DEFAULT NULL,
  `user_role_cpu` float DEFAULT NULL,
  `user_role_hdd` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wiresharks`
--

CREATE TABLE `wiresharks` (
  `ws_id` bigint(15) NOT NULL,
  `ws_tenant` int(11) DEFAULT NULL,
  `ws_lab` varchar(200) DEFAULT NULL,
  `ws_node` int(11) DEFAULT NULL,
  `ws_if` int(11) DEFAULT NULL,
  `ws_net` int(11) DEFAULT NULL,
  `ws_node_name` varchar(150) DEFAULT NULL,
  `ws_if_name` varchar(150) DEFAULT NULL,
  `ws_dc_name` varchar(150) DEFAULT NULL,
  `ws_port` int(11) DEFAULT NULL,
  `ws_ip` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `control`
--
ALTER TABLE `control`
  ADD PRIMARY KEY (`control_name`);

--
-- Indexes for table `lab_sessions`
--
ALTER TABLE `lab_sessions`
  ADD PRIMARY KEY (`lab_session_id`) USING BTREE,
  ADD KEY `lab_session_lid` (`lab_session_lid`) USING BTREE,
  ADD KEY `lab_session_pod` (`lab_session_pod`) USING BTREE;

--
-- Indexes for table `node_sessions`
--
ALTER TABLE `node_sessions`
  ADD PRIMARY KEY (`node_session_id`) USING BTREE,
  ADD UNIQUE KEY `node_session_nid_2` (`node_session_nid`,`node_session_lab`),
  ADD KEY `node_session_lab` (`node_session_lab`),
  ADD KEY `node_session_port` (`node_session_port`),
  ADD KEY `node_session_nid` (`node_session_nid`),
  ADD KEY `node_session_type` (`node_session_type`),
  ADD KEY `node_session_running` (`node_session_running`),
  ADD KEY `node_session_pod` (`node_session_pod`),
  ADD KEY `node_session_iol` (`node_session_iol`);

--
-- Indexes for table `process`
--
ALTER TABLE `process`
  ADD PRIMARY KEY (`process_id`),
  ADD KEY `process_dtotal` (`process_dtotal`),
  ADD KEY `process_dnow` (`process_dnow`),
  ADD KEY `process_utotal` (`process_utotal`),
  ADD KEY `process_unow` (`process_unow`),
  ADD KEY `process_finish` (`process_finish`);

--
-- Indexes for table `process_device`
--
ALTER TABLE `process_device`
  ADD UNIQUE KEY `process_device_id` (`process_device_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`pod`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `online_time` (`online_time`),
  ADD KEY `lab_session` (`lab_session`),
  ADD KEY `offline` (`offline`),
  ADD KEY `active_time` (`active_time`),
  ADD KEY `expired_time` (`expired_time`),
  ADD KEY `user_status` (`user_status`);

--
-- Indexes for table `user_permission`
--
ALTER TABLE `user_permission`
  ADD PRIMARY KEY (`user_per_id`),
  ADD KEY `user_per_role` (`user_per_role`),
  ADD KEY `user_per_name` (`user_per_name`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_role_id`),
  ADD KEY `user_role_name` (`user_role_name`),
  ADD KEY `user_role_ram` (`user_role_ram`),
  ADD KEY `user_role_cpu` (`user_role_cpu`),
  ADD KEY `user_role_hdd` (`user_role_hdd`);

--
-- Indexes for table `wiresharks`
--
ALTER TABLE `wiresharks`
  ADD PRIMARY KEY (`ws_id`),
  ADD KEY `ws_ip` (`ws_ip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lab_sessions`
--
ALTER TABLE `lab_sessions`
  MODIFY `lab_session_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `pod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `user_permission`
--
ALTER TABLE `user_permission`
  MODIFY `user_per_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `user_role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `wiresharks`
--
ALTER TABLE `wiresharks`
  MODIFY `ws_id` bigint(15) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
